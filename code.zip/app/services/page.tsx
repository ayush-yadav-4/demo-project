"use client"

import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Code2, Smartphone, Megaphone, Database, Cog, CreditCard, ArrowRight } from "lucide-react"
import Link from "next/link"

const services = [
  {
    icon: Code2,
    title: "Website Development",
    description: "Modern, responsive websites built with latest technologies",
    href: "/services/web-development",
    features: ["Responsive Design", "SEO Optimized", "High Performance"],
  },
  {
    icon: Smartphone,
    title: "App Development",
    description: "Native and cross-platform mobile apps",
    href: "/services/app-development",
    features: ["iOS & Android", "Cross-platform", "User Friendly"],
  },
  {
    icon: Megaphone,
    title: "Digital Marketing",
    description: "Strategic marketing solutions to boost your presence",
    href: "/services/digital-marketing",
    features: ["SEO", "Social Media", "Content Marketing"],
  },
  {
    icon: Database,
    title: "ERP Solutions",
    description: "Integrate and streamline business processes",
    href: "/services/erp-solutions",
    features: ["Enterprise Ready", "Scalable", "Secure"],
  },
  {
    icon: Cog,
    title: "Software Development",
    description: "Tailored software solutions for complex challenges",
    href: "/services/software-development",
    features: ["Custom Built", "Scalable", "Maintainable"],
  },
  {
    icon: CreditCard,
    title: "Payment Gateway",
    description: "Secure payment processing integrated seamlessly",
    href: "/services/payment-gateway",
    features: ["Secure", "Fast", "Reliable"],
  },
]

export default function ServicesPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 relative">
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-20 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-float" />
        </div>

        <div className="max-w-4xl mx-auto text-center animate-fade-in">
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6 text-balance">
            Our <span className="text-accent">Services</span>
          </h1>
          <p className="text-lg text-foreground/60 max-w-2xl mx-auto leading-relaxed">
            Comprehensive digital solutions designed to transform your business and drive sustainable growth
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, index) => {
              const Icon = service.icon
              return (
                <Link key={service.href} href={service.href} className="group">
                  <div
                    className="h-full p-8 rounded-xl border border-border bg-card hover:border-accent/50 transition-all duration-300 hover:shadow-lg hover:shadow-accent/10 animate-slide-in-up"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <div className="space-y-4">
                      <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                        <Icon className="w-6 h-6 text-accent" />
                      </div>

                      <div>
                        <h3 className="text-xl font-bold text-foreground group-hover:text-accent transition-colors">
                          {service.title}
                        </h3>
                        <p className="text-foreground/60 text-sm mt-2">{service.description}</p>
                      </div>

                      <div className="pt-4 space-y-2">
                        {service.features.map((feature) => (
                          <div key={feature} className="flex items-center gap-2 text-sm text-foreground/60">
                            <div className="w-1.5 h-1.5 bg-accent rounded-full" />
                            {feature}
                          </div>
                        ))}
                      </div>

                      <div className="flex items-center gap-2 text-accent opacity-0 group-hover:opacity-100 transition-opacity pt-4">
                        <span className="text-sm font-semibold">Learn More</span>
                        <ArrowRight className="w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </Link>
              )
            })}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
