"use client"

import { useState, useEffect } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { HeroSection } from "@/components/hero-section"
import { ServicesPreview } from "@/components/services-preview"
import { CompaniesSection } from "@/components/companies-section"
import { AboutRuesafe } from "@/components/about-ruesafe"
import { CompanyStats } from "@/components/company-stats"
import { ClientReviews } from "@/components/client-reviews"
import { CTASection } from "@/components/cta-section"

function DemoVideoSection() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-accent/5 to-primary/5" />
      </div>

      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">
            See Ruesafe in <span className="text-accent">Action</span>
          </h2>
          <p className="text-lg text-foreground/60 max-w-2xl mx-auto">
            Watch how we transform businesses with cutting-edge digital solutions
          </p>
        </div>

        <div className="relative rounded-2xl overflow-hidden glass-blue animate-slide-in-up">
          <div className="relative aspect-video bg-gradient-to-br from-primary/20 via-accent/10 to-primary/20 flex items-center justify-center">
            <iframe
              width="100%"
              height="100%"
              src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=0"
              title="Ruesafe Solutions Demo"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full"
            />
          </div>
        </div>
      </div>
    </section>
  )
}

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <ServicesPreview />
      <AboutRuesafe />
      <CompanyStats />
      <DemoVideoSection />
      <CompaniesSection />
      <ClientReviews />
      <CTASection />
      <Footer />
    </main>
  )
}
