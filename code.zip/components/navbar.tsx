"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X, Sun, Moon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { AuthModal } from "./auth-modal"
import { useTheme } from "./theme-provider"

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [authModalOpen, setAuthModalOpen] = useState(false)
  const [authTab, setAuthTab] = useState<"signin" | "signup">("signin")
  const { theme, toggleTheme } = useTheme()

  const navItems = [
    { label: "Home", href: "/" },
    { label: "Services", href: "/services" },
    { label: "About", href: "/about" },
    { label: "Pricing", href: "/pricing" },
    { label: "Contact", href: "/contact" },
  ]

  const handleAuthClick = (tab: "signin" | "signup") => {
    setAuthTab(tab)
    setAuthModalOpen(true)
    setIsOpen(false)
  }

  return (
    <>
      <nav className="fixed w-full top-0 z-40 glass-dark dark:glass">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
                <span className="text-accent-foreground font-bold">R</span>
              </div>
              <span className="font-bold text-xl text-foreground">Ruesafe</span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="text-foreground hover:text-accent transition-colors duration-300"
                >
                  {item.label}
                </Link>
              ))}
            </div>

            {/* Right side - Auth & Theme */}
            <div className="flex items-center gap-4">
              {/* Theme Toggle */}
              <button
                onClick={() => toggleTheme(theme === "dark" ? "light" : "dark")}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors duration-300"
                aria-label="Toggle theme"
              >
                {theme === "dark" ? <Sun className="w-5 h-5 text-accent" /> : <Moon className="w-5 h-5 text-accent" />}
              </button>

              {/* Auth Buttons */}
              <Button
                variant="outline"
                size="sm"
                className="hidden sm:inline-flex bg-transparent"
                onClick={() => handleAuthClick("signin")}
              >
                Sign In
              </Button>
              <Button
                size="sm"
                className="hidden sm:inline-flex bg-accent hover:bg-accent/90"
                onClick={() => handleAuthClick("signup")}
              >
                Sign Up
              </Button>

              {/* Mobile Menu Toggle */}
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="md:hidden p-2 hover:bg-white/10 rounded-lg transition-colors duration-300"
                aria-label="Toggle menu"
              >
                {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {isOpen && (
            <div className="md:hidden pb-4 space-y-4 animate-slide-in-down">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="block text-foreground hover:text-accent transition-colors duration-300"
                  onClick={() => setIsOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
              <div className="flex gap-2 pt-4">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1 bg-transparent"
                  onClick={() => handleAuthClick("signin")}
                >
                  Sign In
                </Button>
                <Button
                  size="sm"
                  className="flex-1 bg-accent hover:bg-accent/90"
                  onClick={() => handleAuthClick("signup")}
                >
                  Sign Up
                </Button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Auth Modal */}
      <AuthModal isOpen={authModalOpen} onClose={() => setAuthModalOpen(false)} initialTab={authTab} />
    </>
  )
}
