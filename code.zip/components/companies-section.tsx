"use client"

export function CompaniesSection() {
  const companies = [
    { name: "TechCorp", logo: "🏢" },
    { name: "InnovateLabs", logo: "🧪" },
    { name: "DataViz", logo: "📊" },
    { name: "CloudSync", logo: "☁️" },
    { name: "SecureNet", logo: "🔒" },
    { name: "FinFlow", logo: "💰" },
  ]

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 border-t border-b border-border">
      <div className="max-w-7xl mx-auto">
        <p className="text-center text-foreground/60 text-sm font-semibold mb-8 uppercase tracking-wide">
          Trusted by leading companies worldwide
        </p>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 items-center justify-center">
          {companies.map((company, index) => (
            <div
              key={company.name}
              className="flex flex-col items-center justify-center gap-2 opacity-60 hover:opacity-100 transition-opacity duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <span className="text-4xl">{company.logo}</span>
              <span className="text-sm text-foreground/60">{company.name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
