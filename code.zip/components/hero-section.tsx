"use client"

import { ArrowRight, Play } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      <div className="absolute inset-0 -z-10">
        {/* Base gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />

        {/* Aurora-like animated blobs */}
        <div className="absolute top-10 right-1/4 w-96 h-96 bg-accent/25 rounded-full blur-3xl animate-aurora" />
        <div
          className="absolute bottom-20 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-blob-rotate"
          style={{ animationDelay: "2s" }}
        />
        <div
          className="absolute top-1/2 right-10 w-72 h-72 bg-accent/15 rounded-full blur-3xl animate-aurora"
          style={{ animationDelay: "1s" }}
        />

        {/* Animated grid pattern - Globant inspired */}
        <div className="absolute inset-0 opacity-10">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        {/* Scan line effect */}
        <div className="absolute inset-0 opacity-5 pointer-events-none">
          <div className="relative w-full h-full">
            <div
              className="absolute inset-0 bg-gradient-to-b from-accent/30 to-transparent animate-scan-line"
              style={{ height: "100px" }}
            />
          </div>
        </div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-slide-in-left">
            <div className="space-y-4">
              <div className="inline-block px-4 py-2 bg-accent/20 rounded-full border border-accent/50 glass-green">
                <span className="text-accent text-sm font-semibold">Digital Transformation Starts Here</span>
              </div>

              <h1 className="text-5xl lg:text-7xl font-bold text-foreground leading-tight text-pretty">
                Build. Grow. <span className="text-accent">Scale</span>.
              </h1>

              <p className="text-lg text-foreground/70 leading-relaxed">
                Ruesafe empowers businesses with cutting-edge digital solutions. From web and app development to ERP
                systems, we transform your vision into reality.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/contact">
                <Button size="lg" className="w-full sm:w-auto bg-accent hover:bg-accent/90 text-accent-foreground">
                  Start Your Journey
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </Link>
              <button className="flex items-center justify-center gap-2 px-6 py-3 rounded-lg border border-foreground/20 hover:bg-foreground/5 transition-colors duration-300">
                <Play className="w-4 h-4 fill-accent text-accent" />
                <span className="text-foreground">Watch Demo</span>
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-8">
              <div>
                <p className="text-2xl font-bold text-accent">500+</p>
                <p className="text-sm text-foreground/60">Projects Delivered</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-accent">150+</p>
                <p className="text-sm text-foreground/60">Happy Clients</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-accent">50+</p>
                <p className="text-sm text-foreground/60">Team Members</p>
              </div>
            </div>
          </div>

          <div className="relative animate-slide-in-right hidden lg:block">
            {/* Main container with glassmorphic design */}
            <div className="relative aspect-square rounded-2xl overflow-hidden glass-blue">
              {/* Animated background elements */}
              <div className="absolute inset-0 bg-gradient-to-br from-accent/20 via-transparent to-primary/20" />

              {/* Floating animated elements */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative w-64 h-64">
                  {/* Center circle */}
                  <div className="absolute inset-0 rounded-full border-2 border-accent/30 animate-pulse" />
                  <div className="absolute inset-4 rounded-full border-2 border-accent/50 animate-float" />
                  <div className="absolute inset-8 rounded-full border-2 border-accent/70 animate-rotate-slow" />

                  {/* Orbiting dots */}
                  <div className="absolute inset-0 animate-scroll-right">
                    <div className="absolute top-0 left-1/2 w-3 h-3 bg-accent rounded-full -translate-x-1/2 shadow-lg shadow-accent/50" />
                  </div>

                  {/* Center tech icon visualization */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-32 h-32 rounded-xl bg-gradient-to-br from-accent/30 to-primary/30 flex items-center justify-center text-4xl animate-float">
                      💻
                    </div>
                  </div>
                </div>
              </div>

              {/* Edge glow effect */}
              <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
            </div>

            {/* Floating accent orb */}
            <div className="absolute -bottom-6 -right-6 w-40 h-40 bg-accent/20 rounded-full blur-3xl -z-10 animate-blob-rotate" />
          </div>
        </div>
      </div>
    </section>
  )
}
