"use client"

const items = [
  { title: "Fast Delivery", desc: "Quick turnaround without compromising quality" },
  { title: "Expert Team", desc: "50+ professionals dedicated to your success" },
  { title: "Goal-Focused", desc: "Solutions aligned with your business objectives" },
  { title: "Proven Track Record", desc: "500+ successful projects delivered" },
]

export function AboutRuesafe() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-r from-accent/5 via-primary/5 to-accent/5" />
      </div>

      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-slide-in-left">
            <div>
              <div className="inline-block px-4 py-2 bg-accent/20 rounded-full border border-accent/50 mb-4">
                <span className="text-accent text-sm font-semibold">About Ruesafe</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-foreground text-balance">
                Your Partner in Digital Innovation
              </h2>
            </div>

            <p className="text-lg text-foreground/70 leading-relaxed">
              Since our founding, Ruesafe has been committed to delivering exceptional digital solutions that transform
              businesses. With a team of experts spanning web development, mobile apps, digital marketing, and
              enterprise systems, we bring together diverse expertise to solve complex business challenges.
            </p>

            <div className="space-y-4">
              {items.map((item, index) => (
                <div
                  key={index}
                  className="flex gap-4 items-start animate-slide-in-up"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-xl">✓</span>
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">{item.title}</p>
                    <p className="text-sm text-foreground/60">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative animate-slide-in-right hidden lg:block">
            <div className="relative aspect-square rounded-2xl overflow-hidden glass-green">
              <div className="absolute inset-0 bg-gradient-to-br from-accent/30 via-transparent to-primary/20" />
              <div className="absolute inset-0 flex items-center justify-center text-6xl">🚀</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
