"use client"

const stats = [
  { value: "500+", label: "Projects Completed", description: "Delivered across all service verticals" },
  { value: "150+", label: "Happy Clients", description: "From startups to enterprises" },
  { value: "50+", label: "Team Members", description: "Experts in their respective domains" },
  { value: "15+", label: "Years Experience", description: "Industry-leading expertise" },
]

export function CompanyStats() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-accent/5" />
      </div>

      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">By The Numbers</h2>
          <p className="text-lg text-foreground/60 max-w-2xl mx-auto">
            Our impact measured in successful projects, satisfied clients, and years of expertise
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <div
              key={stat.label}
              className="relative p-8 rounded-xl border border-border bg-card/50 backdrop-blur hover:border-accent/50 transition-all duration-300 group overflow-hidden animate-slide-in-up"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-accent/10 to-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="relative z-10 space-y-4">
                <p className="text-4xl font-bold text-accent mb-2">{stat.value}</p>
                <p className="font-semibold text-foreground mb-2">{stat.label}</p>
                <p className="text-sm text-foreground/60">{stat.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
